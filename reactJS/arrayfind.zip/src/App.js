import React from 'react';
import './App.css';

class App extends React.Component {
    constructor(){
        super()
        this.state = {
            text: 99 ,
            todos: [1,2,7,99,100]

        }
    }
    positionName =(value) => {
        this.setState({result: value})
    }
    render() {
        return (
            <div>
                <TODOList todos={this.state.todos} keyfind={this.state.text} positionName={this.positionName}/>
                <p>text you wanna find is : {this.state.text}, posotion in array : {this.state.result}</p>
            </div>
    );
    }
}
class TODOList extends React.Component {
    constructor(){
        super()
        this.state = {
            postion: '',
            newarray: []
        }
    }
    findPosition= () => {
        this.setState({array: this.props.todos})
        for(var i = 0; i<this.props.todos.length; i++) {
            if(this.props.todos[i] === this.props.keyfind) {
                this.props.positionName(i)
                this.setState({position: i})
            }
        }
    }
    filterPosition = () => {
        var array = []
        for(var i = 0; i<this.props.todos.length; i++) {
            if(this.props.todos[i] !== this.props.todos[this.state.position]) {
                array.push(this.props.todos[i])
            }
        }
        this.setState({newarray:array})
    }
    render() {
        return (
            <div>
                {
                    this.props.todos.map(todo => {
                        return <li>{todo}</li>
                    })
                }
                <button onClick={this.findPosition}>Click me !</button>
                <button onClick={this.filterPosition}>Delete it</button><br/>
                This is new array : {
                this.state.newarray.map(todo => {
                    return <li>{todo}</li>
                })
                }
            </div>
        );
    }
}
export default App;
