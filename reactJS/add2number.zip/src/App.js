import React, { Component } from 'react';
import './App.css';

class App extends React.Component {
    constructor(){
        super()
        this.state = {
            data: 2 ,
            data2: 1
        }
    }
    // set data from input to state data
    setStateData = (e) => {
        this.setState({data: e.target.value})
    }
    setStateData2 = (e) => {
        this.setState({data2: e.target.value})
    }
    // get value form child component and set it
    setStateFComponent = (value) => {
        this.setState({total: value})
    }
    render() {
        return (
            <div>
                <input type="number" refs="numberA" onChange={this.setStateData}/>
                <input type="number" refs="numberB" onChange={this.setStateData2}/>
                <H1 setStateFComponent= {this.setStateFComponent} numberA = {this.state.data} numberB = {this.state.data2}></H1>
                <h3>{this.state.total}</h3>
            </div>
    );
    }
}
class H1 extends React.Component {
    constructor(){
        super()
        this.state = {
            data: ''
        }
    }
    add2number = () => {
        let total = parseInt(this.props.numberA) + parseInt(this.props.numberB)
        this.props.setStateFComponent(total)
    }
    render() {
        return(
            <div>
                <button onClick={this.add2number}>Click</button><br/>
                {this.props.numberA} + {this.props.numberB} = {this.state.data}
            </div>
        );
    }
}

export default App;
