import React from 'react';
class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            data: ''
        }
        this.addTwoNumber = this.addTwoNumber.bind(this)
        this.clear = this.clear.bind(this)
        this.setYellow = this.setYellow.bind(this)
    }
    addTwoNumber() {
        let total = parseInt(this.refs.numberA.value) + parseInt(this.refs.numberB.value)
        this.setState({data: total})
    }
    clear() {
        this.refs.numberA.value = ""
        this.refs.numberB.value = ""
        this.setState({data: ''})
    }
    setYellow() {
        document.getElementById("h4").style.backgroundColor = "yellow"
    }
    render() {
        return (
            <div>
                <H1/>
                <input type="number"  ref = "numberA" />
                +<input type="number" ref = "numberB" /><br/>
                <button onClick={this.addTwoNumber}>Click to add two number</button>
                <button onClick={this.setYellow}>Click to yellow h4</button>
                <button onClick={this.clear}>Click to clear</button>
                <h4 id="h4">{this.state.data}</h4>
            </div>
        );
    }
}
class H1 extends React.Component {
    render() {
        return(
            <h1>This is HEADER from child component</h1>
        );
    }
}

export default App;