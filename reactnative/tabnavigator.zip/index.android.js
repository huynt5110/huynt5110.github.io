import React, { Component } from 'react';
import {
  AppRegistry,
  View
} from 'react-native';
import App from './src/App';
AppRegistry.registerComponent('demo1', () => App);
