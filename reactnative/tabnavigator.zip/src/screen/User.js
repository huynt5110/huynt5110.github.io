import React, {Component} from 'react';
import {View, Text} from 'react-native';

export default class User extends Component {
  render() {
    const { params } = this.props.navigation.state;
    return(
      <View>
        <Text>This is user</Text>
      </View>
    );
  }
}