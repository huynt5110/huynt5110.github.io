import React, {Component} from 'react';
import {View, Text, Button, TextInput} from 'react-native';

export default class Home extends Component {
  constructor(props) {
    super(props)
    this.state = {
      username: ''
    };
  }
  static navigationOptions = {
    title: 'Welcome Home',
    tabBarLabel: 'Home',
  };
  render() {
    const { navigate } = this.props.navigation;
    return(
      <View>
        <TextInput type='text' placeholder='Input name' onChangeText={(username) => this.setState({username})}/>
        <Button
          onPress={() => navigate('Manhinh_User',{user: this.state.username})}
          title="Switch to User"
        />
        <Button
          onPress={() => this.props.navigation.navigate('Notifications')}
          title="Go to notifications"
        />
      </View>
    );
  }
}