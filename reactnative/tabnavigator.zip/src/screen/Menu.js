import React, {Component} from 'react';
import {View, Text} from 'react-native';

export default class menu extends Component {
  render() {
    return(
      <View>
        <Text>Menu</Text>
      </View>
    );
  }
}