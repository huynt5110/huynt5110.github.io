import React from 'react';
import { StackNavigator,TabNavigator } from 'react-navigation';
import Home from './screen/Home'
import User from './screen/User'
import Detail from './screen/Detail'
import Menu from './screen/Menu'

/*const HomeStack = StackNavigator({
  Manhinh_Home: {screen: Home},
  Manhinh_User: {screen: User}
})*/
const HomeStack = TabNavigator({
  Manhinh_User: {screen: User},
  Manhinh_Home: {screen: Home},
  Manhinh_Detail: {screen: Detail},
  Manhinh_Menu: {screen: Menu}
})
export default HomeStack;