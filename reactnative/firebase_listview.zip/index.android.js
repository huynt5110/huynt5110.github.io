/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ListView,
  TextInput
} from 'react-native';
import firebase from '../splash/api/api';
export default class splash extends Component {
  constructor(props) {
    database = firebase.database();
    user = database.ref('User');
    items= [];
    super(props);
    this.state= {
      usetname : '',
      password : '',
      dataSource: new ListView.DataSource ({rowHasChanged: (r1,r2)=> r1!==r2}),
    };
  }
  componentWillMount() {
    database.ref('User').on('value',(snap) => {
      items= [];
      snap.forEach((data) =>{
        items.push({
          key: data.key,
          dataobj: data.val(),
        })
      }) 
      this.setState({dataSource: this.state.dataSource.cloneWithRows(items)});
    });
  }
  removeData = (data) => {
    user.child(data.key).remove()
  }
  renderRow = (data) => {
    return(
        <TouchableOpacity onPress={() => this.removeData(data)}>
        <Text>----------------------------</Text>
          <Text>Key: {data.key}</Text>
          <Text>username: {data.dataobj.username}</Text>
          <Text>password: {data.dataobj.password}</Text>
        </TouchableOpacity>
      );
  }
  submit = () => {  
    user.push(
    {
      username : this.state.username,
      password: this.state.password
    },)
  }
  render() {
    return (
      <View>
        <TextInput placeholder = {"username"} onChangeText= {(value)=> this.setState({username: value})}/>
        <TextInput placeholder = {"password"} onChangeText= {(value)=> this.setState({password: value})}/>
        <Text onPress= {this.submit}>Submit</Text>
        <ListView style={{marginTop: 50}} dataSource={this.state.dataSource} renderRow={this.renderRow}/>
      </View>
    );
  }
}

AppRegistry.registerComponent('splash', () => splash);
