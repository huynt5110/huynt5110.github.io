/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  TouchableOpacity,
  View
} from 'react-native';
import PushNotification from 'react-native-push-notification'
export default class notify extends Component {
  showNotification = () => {
    PushNotification.localNotification({
      ticker: "My Notification Ticker",
      bigText: "Long time no see",
      subText: "Hehe",
      message: "My Notification Message",
      title: "My Notification Title"
    });
  }
  render() {
    return (
      <View>
          <TouchableOpacity onPress={this.showNotification}>
            <Text>Click me</Text>
          </TouchableOpacity>
      </View>
    );
  }
}

AppRegistry.registerComponent('notify', () => notify);
