/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */
 // import firebase from '../splash/api/api';
import SqlService from './src/SqlService';
// import React from 'react-native';
// import SQLite from 'react-native-sqlite-storage';
import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ListView,
  TextInput
} from 'react-native';

export default class splash extends Component {
  constructor(props) {
    super(props);
    this.state = {
      dataS: new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})
    }
  }
  componentWillMount() {
        // SqlService.query('CREATE TABLE IF NOT EXISTS DATA (id TEXT)').then(res => {
      SqlService.insert('DATA',["id"],["1"]).then(res => {
        console.log("rea"+res);
        SqlService.select('DATA','*').then(rs => {
          this.setState({
            dataS: this.state.dataS.cloneWithRows(rs)
          })
        });
      });
    // });
  }
  renderRow = (variable) => {
    return(
      <View style={{flex: 1, paddingTop:20, paddingLeft:20, flexDirection: 'row'}}>
        <Text style={{flex: 1}}>ID: {variable.id}</Text>
      </View>
    );
  }
  render() {
    return (
      <View>
        <Text>
          Welcome to React Native!
        </Text>
        <ListView dataSource= {this.state.dataS} renderRow={this.renderRow}/>
      </View>
    );
  }
}

AppRegistry.registerComponent('splash', () => splash);
