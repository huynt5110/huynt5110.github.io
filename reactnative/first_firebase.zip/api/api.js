import * as firebase from 'firebase';
var config = {
    apiKey: "AIzaSyByafMGGLZRltnx89-fA2nBt1VVatBIt_k",
    authDomain: "demofirebase-4fec3.firebaseapp.com",
    databaseURL: "https://demofirebase-4fec3.firebaseio.com",
    projectId: "demofirebase-4fec3",
    storageBucket: "demofirebase-4fec3.appspot.com",
    messagingSenderId: "730353265937"
  };
firebase.initializeApp(config);
export default firebase;