/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TextInput
} from 'react-native';
import firebase from '../splash/api/api';
export default class splash extends Component {
  constructor(props) {
    super(props);
    this.state= {
      usetname : '',
      password : ''
    }
    database = firebase.database();
    user = database.ref('User');
  }
  submit = () =>{
    user.push ({
      username: this.state.username,
      password: this.state.password
    },() => alert('done !'))
  }
  render() {
    return (
      <View>
        <TextInput placeholder={"username"} onChangeText= {(value)=> this.setState({username: value})}/>  
        <TextInput placeholder={"password"} onChangeText= {(value)=> this.setState({password: value})}/>
        <Text onPress= {this.submit}>Submit</Text>
      </View>
    );
  }
}

AppRegistry.registerComponent('splash', () => splash);
