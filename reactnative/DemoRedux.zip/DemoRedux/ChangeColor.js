import React, { Component } from 'react';
import { View, Text, StyleSheet,TouchableOpacity } from 'react-native';
import {connect} from 'react-redux';
class ChangeColor extends Component {
  render() {
      return(
        <TouchableOpacity style={{backgroundColor:'black'}} onPress= {() => {this.props.dispatch({type: 'CHANGE'})}}>
          <Text style={{color:'white'}}>Change Color</Text>
        </TouchableOpacity>
      );
    }
}
export default connect()(ChangeColor);